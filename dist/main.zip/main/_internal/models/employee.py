class Employee:
    def __init__(self, id, first_name, last_name, section):
        self.id = id
        self.first_name = first_name
        self.last_name = last_name
        self.section = section
        self.tasks = []
