from kivymd.uix.screen import MDScreen

class ConfigScreen(MDScreen):
    pass